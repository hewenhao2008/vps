#!/bin/sh
# "tap-combi", "1500", "0", "", "", "init"

# ip address add 10.179.255.1/255.255.255.0 dev tap-combi
# ifconfig tap-combi up

exit 0
