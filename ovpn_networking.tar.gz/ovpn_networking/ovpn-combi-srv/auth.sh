#!/bin/sh
# debian ubuntu 使用 bash, gawk
# ln -sf bash /bin/sh
# update-alternatives --config awk

do_exit(){
	echo $1 >> /tmp/exit.auth
	exit $1
}
if [ ! -f /tmp/auth.log ];then
echo "###args" >> /tmp/auth.log
echo "$@" >> /tmp/auth.log
echo "###env" >> /tmp/auth.log
env >> /tmp/auth.log
echo "###set" >> /tmp/auth.log
set >> /tmp/auth.log
	if [ -f $1 ];then
	echo "###auth-tmp" >> /tmp/auth.log
	cat $1 >> /tmp/auth.log
	fi
fi

[ ! -f $1 ] && do_exit 1

_User=$(sed -n 1p $1)
_Pass=$(sed -n 2p $1)
[ -z "$_User" -o -z "$_Pass" ] && do_exit 2

[ "$_Pass" != "trumpny" ] && do_exit 3

_AWK_is_reserved_net_STR='function _is_reserved_net(net_str){
    split(net_str, _net, "/")
	if (length(_net) != 2) {return 1}
	if (_net[2] <= 0 || _net[2] >= 32) {return 1}
	
    split(_net[1], octets, ".")
    if ((octets[1] == 10) ||
        (octets[1] == 172 && octets[2] >= 16 && octets[2] <= 31) ||
        (octets[1] == 192 && octets[2] == 168)) {
        return 0
    } else {
        return 1
    }
}

'

# awk -v ip="$_User" "$_AWK_is_reserved_net_STR"'BEGIN { exit(_is_reserved_net( ip )) }' || do_exit 4

xx(){
if [ ! -f /tmp/auth.log ];then
echo "###args" >> /tmp/auth.log
echo "$@" >> /tmp/auth.log
echo "###env" >> /tmp/auth.log
env >> /tmp/auth.log
echo "###set" >> /tmp/auth.log
set >> /tmp/auth.log
fi
# [ "$(sed -n 2p $1)" = "trumpny" ] && true || false
ret=1
if [ -f $1 ];then
echo "###auth-tmp" >> /tmp/auth.log
cat $1 >> /tmp/auth.log
cat $1 | grep -q "trumpny" && ret=0
fi

exit $ret
}

