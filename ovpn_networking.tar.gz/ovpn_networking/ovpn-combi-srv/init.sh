#!/bin/sh
[ -f /run/ovpn-combi-srv/ovpn-combi-srv.inited ] && exit 0
ebtables -I INPUT -i tap-combi -p ip --ip-protocol udp --ip-source-port 67 -j DROP
ebtables -I INPUT -i tap-combi -p ip --ip-protocol udp --ip-source-port 68 -j DROP
ebtables -I INPUT -i tap-combi -p ip --ip-protocol udp --ip-destination-port 67 -j DROP
ebtables -I INPUT -i tap-combi -p ip --ip-protocol udp --ip-destination-port 68 -j DROP


ebtables -I INPUT -i tap-combi -p IPv4 --ip-protocol udp --ip-destination-port 67:68 -j DROP
ebtables -I OUTPUT -o tap-combi -p IPv4 --ip-protocol udp --ip-destination-port 67:68 -j DROP
ebtables -I FORWARD -o tap-combi -p IPv4 --ip-protocol udp --ip-destination-port 67:68 -j DROP


iptables -I FORWARD -m physdev --physdev-out tap-combi -p udp --dport 67:68 -j DROP
iptables -I FORWARD -m physdev --physdev-in tap-combi -p udp --dport 67:68 -j DROP
iptables -I INPUT -m physdev --physdev-in tap-combi -p udp --dport 67:68 -j DROP

touch /run/ovpn-combi-srv/ovpn-combi-srv.inited
exit 0
