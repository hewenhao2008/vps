#!/bin/sh
if [ ! -f /tmp/disconn.log ];then
echo "###args" >> /tmp/disconn.log
echo "$@" >> /tmp/disconn.log
echo "###env" >> /tmp/disconn.log
env >> /tmp/disconn.log
echo "###set" >> /tmp/disconn.log
set >> /tmp/disconn.log
fi

ip route del $username via $ifconfig_pool_remote_ip dev ovpn-combi-srv

