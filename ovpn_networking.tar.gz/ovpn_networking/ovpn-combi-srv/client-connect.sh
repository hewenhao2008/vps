#!/bin/sh
if [ ! -f /tmp/conn.log ];then
echo "###args" >> /tmp/conn.log
echo "$@" >> /tmp/conn.log
echo "###env" >> /tmp/conn.log
env >> /tmp/conn.log
echo "###set" >> /tmp/conn.log
set >> /tmp/conn.log
fi

ip route add $username via $ifconfig_pool_remote_ip dev ovpn-combi-srv

