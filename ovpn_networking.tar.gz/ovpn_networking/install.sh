#!/bin/sh

sudo cp -rf ./ovpn-combi-srv /opt/

for i in $(ls /opt/ovpn-combi-srv/*.sh)
do
	sudo chmod 777 $i
done

sudo mkdir /var/log/ovpn-combi-srv
sudo touch /var/log/ovpn-combi-srv/ovpn-combi-srv.log

sudo rm -rf /etc/init.d/openvpn
sudo rm -rf /etc/openvpn

sudo rm -rf /usr/sbin/openvpn
sudo cp ./bins/openvpn.x86_64 /usr/sbin/openvpn
sudo chmod 777 /usr/sbin/openvpn
sudo cp ./system/ovpn-combi-srv.service /etc/systemd/system/ovpn-combi-srv.service
sudo chmod 777 /etc/systemd/system/ovpn-combi-srv.service

sudo /etc/init.d/openvpn -rf
sudo systemctl daemon-reload
sudo systemctl enable ovpn-combi-srv.service
sudo systemctl start ovpn-combi-srv.service
